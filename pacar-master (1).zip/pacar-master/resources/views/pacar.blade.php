<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <title>{{$pesan}}</title>

    <meta property="og:image" name="og:image" content="{{$gambar}}">
    <meta property="og:title" name="og:title" content="{{$pesan}}">
    <meta property="og:url" name="og:url" content="{{url('/' . $request->path())}}">

    <meta name="description" content="{{$pesan}}">
    <meta name="author" content="Diana">
  </head>
  <body>

    <h1>SHARE KE FACEBOOK!</h1>

  </body>
</html>
